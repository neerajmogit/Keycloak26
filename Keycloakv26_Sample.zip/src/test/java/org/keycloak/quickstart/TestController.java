package org.keycloak.quickstart;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.Customizer;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TestController {

    @GetMapping("/")
    public String index() {
        return "Resource server up and running!";
    }

    @PreAuthorize("hasAuthority('SCOPE_user')")
    @GetMapping("/user")
    public String user() {
        return "Hello, user!";
    }

    @PreAuthorize("hasAuthority('SCOPE_user_premium')")
    @GetMapping("/premium")
    public String premium() {
        return "Hello, premium user!";
    }
	
    @GetMapping("/")
    public String home(@AuthenticationPrincipal OidcUser user) {
        if (user != null) {
            return "Hello, " + user.getPreferredUsername() + "! You are authenticated.";
        } else {
            return "You are not authenticated.";
        }
    }
    
    @GetMapping("/user-info")
    public Object userInfo(@AuthenticationPrincipal OidcUser user) {
        return user != null ? user.getClaims() : "No user authenticated";
    }
}

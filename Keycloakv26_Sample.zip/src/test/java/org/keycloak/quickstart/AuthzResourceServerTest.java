//package org.keycloak.quickstart;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.security.oauth2.jwt.Jwt;
//import org.springframework.security.oauth2.jwt.JwtDecoder;
//import org.springframework.test.web.servlet.MockMvc;
//
//import java.time.Instant;
//import java.util.Collections;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//@SpringBootTest
//@AutoConfigureMockMvc
//public class AuthzResourceServerTest {
//
//    @Autowired
//    private MockMvc mockMvc;
//
//    @MockBean
//    private JwtDecoder jwtDecoder;
//
//    private Jwt userJwt;
//    private Jwt adminJwt;
//
//    @BeforeEach
//    public void setup() {
//        // Create a mock user JWT
//        Map<String, Object> userClaims = new HashMap<>();
//        userClaims.put("preferred_username", "test-user");
//        
//        Map<String, Object> realmAccess = new HashMap<>();
//        realmAccess.put("roles", List.of("user"));
//        userClaims.put("realm_access", realmAccess);
//        
//        userJwt = Jwt.withTokenValue("token")
//                .header("alg", "RS256")
//                .subject("test-user")
//                .issuedAt(Instant.now())
//                .expiresAt(Instant.now().plusSeconds(300))
//                .claims(claims -> claims.putAll(userClaims))
//                .build();
//
//        // Create a mock admin JWT
//        Map<String, Object> adminClaims = new HashMap<>();
//        adminClaims.put("preferred_username", "test-admin");
//        
//        Map<String, Object> adminRealmAccess = new HashMap<>();
//        adminRealmAccess.put("roles", List.of("user", "admin"));
//        adminClaims.put("realm_access", adminRealmAccess);
//        
//        adminJwt = Jwt.withTokenValue("admin-token")
//                .header("alg", "RS256")
//                .subject("test-admin")
//                .issuedAt(Instant.now())
//                .expiresAt(Instant.now().plusSeconds(300))
//                .claims(claims -> claims.putAll(adminClaims))
//                .build();
//    }
//
//    @Test
//    public void testUserEndpoint() throws Exception {
//        // Mock the JWT decoder to return our user JWT
//        when(jwtDecoder.decode(anyString())).thenReturn(userJwt);
//
//        // Test access to the user endpoint
//        mockMvc.perform(get("/api/user")
//                .header("Authorization", "Bearer token"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.user_name").value("test-user"));
//    }
//
//    @Test
//    public void testAdminEndpoint_withUserRole() throws Exception {
//        // Mock the JWT decoder to return our user JWT (which doesn't have admin role)
//        when(jwtDecoder.decode(anyString())).thenReturn(userJwt);
//
//        // Test access to the admin endpoint - should be forbidden
//        mockMvc.perform(get("/api/admin")
//                .header("Authorization", "Bearer token"))
//                .andExpect(status().isForbidden());
//    }
//
//    @Test
//    public void testAdminEndpoint_withAdminRole() throws Exception {
//        // Mock the JWT decoder to return our admin JWT
//        when(jwtDecoder.decode(anyString())).thenReturn(adminJwt);
//
//        // Test access to the admin endpoint - should be allowed
//        mockMvc.perform(get("/api/admin")
//                .header("Authorization", "Bearer admin-token"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.user_name").value("test-admin"));
//    }
//
//    @Test
//    public void testUnauthenticatedAccess() throws Exception {
//        // Test access without authentication
//        mockMvc.perform(get("/api/user"))
//                .andExpect(status().isUnauthorized());
//    }
//}

package org.keycloak.quickstart;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Aspect   //Marks this class as an Aspect, which contains cross-cutting concerns (in this case, interception).
@Component
public class FilterInterceptorAspect {
	
//	private static final Logger logger = LoggerFactory.getLogger(FilterInterceptorAspect.class);
	private static final Logger logger = LogManager.getLogger(FilterInterceptorAspect.class);

																		    			//@Around("execution(* javax.servlet.Filter.doFilter(..)) && !within(FilterInterceptorAspect)")
																		    			//@Around("execution(* javax.servlet.Filter.doFilter(..)) && within(org.springframework.security.web.FilterChainProxy)")
	@Around("execution(* javax.servlet.Filter.doFilter(..)) && within(org.springframework.security.web..*) && !within(org.keycloak.quickstart.FilterInterceptorAspect)")
							      /*    && !within(FilterInterceptorAspect) --> This part of the pointcut ensures that the aspect itself doesn't intercept its own doFilter 
							       * 	 method (to avoid infinite recursion if you were to add a doFilter method in the aspect).*/
    public Object interceptDoFilter(ProceedingJoinPoint joinPoint) throws Throwable {
        logger.info("Intercepted doFilter() begins" );    	
								    	 	// Represents the method invocation being intercepted. It allows you to access the target object (the filter), 
								    		//  the method arguments, and to proceed with the original method invocation using joinPoint.proceed().
    	jakarta.servlet.Filter filter = (jakarta.servlet.Filter) joinPoint.getTarget();
        Object[] args = joinPoint.getArgs();
        
        jakarta.servlet.ServletRequest request = (jakarta.servlet.ServletRequest) args[0];
        jakarta.servlet.ServletResponse response = (jakarta.servlet.ServletResponse) args[1];
        jakarta.servlet.FilterChain chain = (jakarta.servlet.FilterChain) args[2];
        
																												//        logger.info("Intercepted doFilter() in filter: " + filter.getClass().getName());
																												//        logger.info("Request URI: " + ((jakarta.servlet.http.HttpServletRequest) request).getRequestURI());
																												
																												        // Inspect arguments if needed
																												//         logger.info("Request: " + request);
																												//         logger.info("Response: " + response);
																												//         logger.info("Chain: " + chain);
																												
																												        // Before filter execution
																												        // You can access and modify request/response here if needed

        Object result = null;
        try {
            result = joinPoint.proceed(); // Invoke the original doFilter method
        } catch (Throwable throwable) {
            System.err.println("Exception in filter " + filter.getClass().getName() + ": " + throwable.getMessage());
            throw throwable;
        } finally {
		            // After filter execution (both success and exception)
		            // You can perform actions after the filter has processed the request
        }

        return result;
    }
}
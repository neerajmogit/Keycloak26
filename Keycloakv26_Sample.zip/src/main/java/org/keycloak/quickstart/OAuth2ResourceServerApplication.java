package org.keycloak.quickstart;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class OAuth2ResourceServerApplication {
	private static final Logger logger = LogManager.getLogger(OAuth2ResourceServerApplication.class);
	
    public static void main(String[] args) {
        SpringApplication.run(OAuth2ResourceServerApplication.class, args);
        logger.info("OAuth2ResourceServerApplication.main() " );      
    }
}

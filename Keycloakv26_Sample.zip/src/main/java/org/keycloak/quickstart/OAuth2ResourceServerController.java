package org.keycloak.quickstart;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.security.access .prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.bind.annotation.GetMapping;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.security.Principal;

@RestController
public class OAuth2ResourceServerController {

	private static final Logger logger = LogManager.getLogger(OAuth2ResourceServerController.class);
	
    @GetMapping("/")
    public String home(Principal principal) {
    	
    	String leftStr = "<html><body><font size=\"14\" color =\"green\">  <br><br>Welcome, ",
    	         rightStr = "</font></body></html>";
    	logger.info("  @GetMapping(\"/\") OAuth2ResourceServerController. home()  " + principal.getName());

    	return "\n*****************************************\n"+leftStr+ principal.getName() + "! "+rightStr;
    }

    @GetMapping("/api/user")
    @PreAuthorize("hasAnyRole('user', 'user_premium')")
    public String userEndpoint() {
        return "This is an API-USER user endpoint";
    } 

					  //    
					//    @GetMapping("/api/user")
					//    @PreAuthorize("hasRole('user)")
					//    public ResponseEntity<String> test() {
					//        return ResponseEntity.ok("Test endpoint /api/user is working");
					//    }
					
					//    @GetMapping("/api/premium")
					//    @PreAuthorize("hasRole('user_premium')")
					//    public String premiumEndpoint() {
					//        return "This is a premium endpoint";
					//    }
					
						
					//    @GetMapping("/api/user")
					//    public Map<String, Object> user(@AuthenticationPrincipal Jwt jwt) {
					//        return Collections.singletonMap("user_name", jwt.getClaimAsString("preferred_username"));
					//    }
					//
					//    @GetMapping("/api/admin")
					//    public Map<String, Object> admin(@AuthenticationPrincipal Jwt jwt) {
					//        return Collections.singletonMap("user_name", jwt.getClaimAsString("preferred_username"));
					//    }
}
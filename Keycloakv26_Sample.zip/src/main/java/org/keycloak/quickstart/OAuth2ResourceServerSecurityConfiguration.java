package org.keycloak.quickstart;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class OAuth2ResourceServerSecurityConfiguration {
	private static final Logger logger = LogManager.getLogger(OAuth2ResourceServerSecurityConfiguration.class);
										//    @Value("${spring.security.oauth2.resourceserver.jwt.issuer-uri}")
										//    private String issuerUri;
   
    @Configuration
    @EnableWebSecurity
    public class SecurityConfig {

        @Bean
        public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        	logger.info("  SecurityConfig.securityFilterChain(. home()  " + http.toString());
        	
            return http
			                .authorizeHttpRequests(authorize -> authorize
											                	.requestMatchers("/api/user").hasRole("user") // Protect /api/user	.Also in DEV env, we do have a Keycloak user "alice", with role: "user
											                    .anyRequest().authenticated()   /* This configuration requires all requests to be authenticated. However, it doesn't explicitly 
											                    											      tell Spring Security, how to authenticate (i.e., trigger the OAuth2 login flow) for unauthenticated requests to, so, 
											                    											      we need specific URL, below */
			                								)
			                .oauth2Login(oauth2 -> oauth2  // This is the ideal way for a single provider. Spring Security will automatically redirect to
													                        // "/oauth2/authorization/myClientmyRealm" when an unauthenticated
													                        // user tries to access a protected resource.
			                        .defaultSuccessUrl("/", true) // Always redirect to the root after successful login
			                )			                
//			                .oauth2Login(oauth2 -> oauth2.loginPage("/oauth2/authorization/keycloak")  //
//                					.defaultSuccessUrl("/")		
//                					//If we use controller methods with [specific user roles], then we will need the oidcUserService method!
//                					// .userInfoEndpoint(userInfo -> userInfo
//                												//.oidcUserService(oidcUserService())
//			                				) 		//Use specific URL if needed
			                .logout(logout -> logout
				                		.logoutRequestMatcher(new AntPathRequestMatcher("/logout")) // Specify the logout URL
				                		.logoutSuccessUrl("/") 	           // Redirect to the root URL after successful logout
				                		.invalidateHttpSession(true)      // Invalidate the HTTP session
				                		.clearAuthentication(true)          // Clear the SecurityContext
				                		.deleteCookies("JSESSIONID") // Delete the session cookie
			                		)
			               .build();
        }

        
//        private OAuth2UserService<OAuth2UserRequest, OAuth2User> oidcUserService() {
//            return new OAuth2UserService<OAuth2UserRequest, OAuth2User>() {
//                @Override
//                public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
//                    OidcUser oidcUser = (OidcUser) new DefaultOidcUserService().loadUser(userRequest);
//                    Set<GrantedAuthority> authorities = new HashSet<>();
//                    oidcUser.getAuthorities().forEach(authority -> authorities.add(authority));
//
//                    // Map Keycloak roles to Spring Security authorities
//                    String username = oidcUser.getPreferredUsername();
//                    if ("admin".equals(username)) {
//                        authorities.add(new SimpleGrantedAuthority("ROLE_admin"));
//                        authorities.add(new SimpleGrantedAuthority("ROLE_db-access")); // admin also has db-access
//                    } else if ("dbuser1".equals(username) || "dbuser2".equals(username)) {
//                        authorities.add(new SimpleGrantedAuthority("ROLE_db-access"));
//                    }   else if ("alice".equals(username))    {
//                          authorities.add(new SimpleGrantedAuthority("ROLE_user"));
//                     }   else if ("jdoe".equals(username))  {
//                          authorities.add(new SimpleGrantedAuthority("ROLE_user"));
//                     }
//                    //You can add more roles as per your requirement
//                    return new CustomOidcUser(oidcUser, authorities);
//                }
//            };
//        }
//
//        static class CustomOidcUser extends OidcUser {
//            private final Set<GrantedAuthority> authorities;
//
//            public CustomOidcUser(OidcUser oidcUser, Set<GrantedAuthority> authorities) {
//                super(oidcUser);
//                this.authorities = authorities;
//            }
//
//            @Override
//            public Set<GrantedAuthority> getAuthorities() {
//                return authorities;
//            }
//        }
        
        
    }// Class SecurityConfig ENDs



																		    /*
																							     @Bean
																							    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
																							        http
																							            .authorizeHttpRequests(authorize -> authorize
																							                .anyRequest().authenticated()
																							            )
																							            .oauth2ResourceServer(oauth2 -> oauth2
																							                .jwt(jwt -> jwt.decoder(jwtDecoder()))
																							            );
																							        return http.build();
																							    }
																							
																							    @Bean
																							    JwtDecoder jwtDecoder() {
																							        return NimbusJwtDecoder.withJwkSetUri(jwkSetUri).build();
																							    }
																		     * */
    
    
    /*     //  -------------------------------------------------------------------------------------------------------
								    private Converter<Jwt, AbstractAuthenticationToken> jwtAuthenticationConverter() {
								        JwtAuthenticationConverter jwtConverter = new JwtAuthenticationConverter();
								        	jwtConverter.setJwtGrantedAuthoritiesConverter(new KeycloakRoleConverter());
								        
								        return jwtConverter;
								    }
								
								    @Bean
								    public JwtDecoder jwtDecoder() {
								        return JwtDecoders.fromIssuerLocation(issuerUri);
								    }
								
								    static class KeycloakRoleConverter implements Converter<Jwt, Collection<GrantedAuthority>> {
								        @Override
								        public Collection<GrantedAuthority> convert(Jwt jwt) {
								            // Extract realm roles
								            Map<String, Object> realmAccess = jwt.getClaimAsMap("realm_access");
								            if (realmAccess == null || realmAccess.isEmpty()) {
								                return Collections.emptyList();
								            }
								
								            @SuppressWarnings("unchecked")
								            List<String> roles = (List<String>) realmAccess.get("roles");
								            if (roles == null || roles.isEmpty()) {
								                return Collections.emptyList();
								            }
								
								            // Convert to Spring Security GrantedAuthority objects
								            return roles.stream()
								                .map(role -> new SimpleGrantedAuthority("ROLE_" + role.toUpperCase()))
								                .collect(Collectors.toList());
								        }
								    }
    //  ------------------------------------------------------------------------------------------------------- */    
}
